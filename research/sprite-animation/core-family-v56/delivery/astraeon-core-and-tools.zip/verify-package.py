from pathlib import Path
import hashlib,json,importlib.util,argparse
P=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--output',type=Path);a=p.parse_args()
for r in json.loads((P/'FILES.json').read_text())['files']:
 f=P/r['path'];assert f.is_file()and hashlib.sha256(f.read_bytes()).hexdigest()==r['sha256'],r['path']
def load(n):
 s=importlib.util.spec_from_file_location(n,P/'tools'/('sprite-'+n+'-review.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
D=json.loads((P/'catalog.json').read_text());c=load('coverage').evaluate(D,P);assert c['pass'],c['errors'];motion=load('motion');contact=load('contact');layer=load('layer-contact');results={}
for v in ['N','W','E','S']:
 f=P/'profiles'/(v+'-motion.json');m=motion.evaluate(json.loads(f.read_text()),f.parent);assert m['motion_profile_pass'];f=P/'profiles'/(v+'-contact.json');x=(layer if v=='S'else contact).evaluate(json.loads(f.read_text()),f.parent);assert x['layer_contact_pass'if v=='S'else'visible_surface_contact_pass'];results[v]={'motion':True,'contact':True,'qualified_layers':v=='S'}
r={'package_pass':True,'authored_clips':48,'exported_exposures':sum(len(c['frames'])for d in D['actions'].values()for c in d['clips'].values()),'pickup_checks':results,'scope':'Current package inventory, coverage/manual receipts and included motion/contact profiles. Full browser/source/world diagnostics are separately recorded in research reports.'}
if a.output:a.output.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
